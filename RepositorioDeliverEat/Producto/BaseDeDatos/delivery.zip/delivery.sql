-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2018 at 02:51 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `delivery`
--

-- --------------------------------------------------------

--
-- Table structure for table `carrito`
--

CREATE TABLE `carrito` (
  `comida` text NOT NULL,
  `cantidad` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` int(11) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carrito`
--

INSERT INTO `carrito` (`comida`, `cantidad`, `descripcion`, `precio`, `id_cliente`, `id`) VALUES
('coca cola', 1, '', 40, 1, 21),
('ravioles', 4, 'sin salsa', 90, 1, 22),
('tallarines con salsa blanca', 1, 'con salsa blanca', 80, 1, 24);

-- --------------------------------------------------------

--
-- Table structure for table `comidas`
--

CREATE TABLE `comidas` (
  `id_comida` int(11) NOT NULL,
  `nombre_comida` text NOT NULL,
  `tipo_comida` text NOT NULL,
  `precio` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comidas`
--

INSERT INTO `comidas` (`id_comida`, `nombre_comida`, `tipo_comida`, `precio`) VALUES
(1, 'tallarines con salsa blanca', 'pastas', 80),
(2, 'ravioles', 'pastas', 90),
(3, 'canelones', 'pastas', 100),
(4, 'tirabuson', 'pastas', 60),
(5, 'lomito', 'sandwiches', 120),
(6, 'hamburguesa', 'sandwiches', 80),
(7, 'sandwich de miga', 'sandwiches', 40),
(8, 'pebete', 'sandwiches', 40),
(9, 'especial', 'pizzas', 100),
(10, 'napolitana', 'pizzas', 110),
(11, 'fugazzeta', 'pizzas', 105),
(12, 'calabreza', 'pizzas', 105),
(13, 'coca cola', 'bebidas', 40),
(14, 'fanta', 'bebidas', 40),
(15, 'sprite', 'bebidas', 35),
(16, 'paso de los toros', 'bebidas', 35),
(17, 'prity', 'bebidas', 35),
(18, 'scheepers', 'bebidas', 40);

-- --------------------------------------------------------

--
-- Table structure for table `datos_pedido`
--

CREATE TABLE `datos_pedido` (
  `domicilio` text NOT NULL,
  `forma_pago` text NOT NULL,
  `importe_efectivo` text NOT NULL,
  `fecha_entrega` text NOT NULL,
  `hr_entrega` text NOT NULL,
  `id_cliente` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datos_pedido`
--

INSERT INTO `datos_pedido` (`domicilio`, `forma_pago`, `importe_efectivo`, `fecha_entrega`, `hr_entrega`, `id_cliente`) VALUES
('Julio Borda', 'efectivo', '999', '2018-09-01', '12:10', 1),
('Octavio Pinto', 'visa', '0', '2018-09-05', '12:12', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carrito`
--
ALTER TABLE `carrito`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comidas`
--
ALTER TABLE `comidas`
  ADD PRIMARY KEY (`id_comida`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carrito`
--
ALTER TABLE `carrito`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `comidas`
--
ALTER TABLE `comidas`
  MODIFY `id_comida` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
